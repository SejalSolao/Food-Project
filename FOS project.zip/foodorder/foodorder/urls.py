from django.contrib import admin

from django.urls import path, include
from myapp import views
from django.contrib.auth import views as auth_views
from django.urls import path


# Import the custom logout view

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", views.index, name="index"),
    path("about/", views.about, name="about"),
    path("contact/", views.contact, name="contact"),
    path("feature/", views.feature, name="feature"),
    path("menu/", views.menu, name="menu"),
    path("account/", views.account, name="account"),
    path("account/register", views.register, name="handleregister"),
    path("account/login", views.login, name="handlelogin"),
    path("book/", views.book_view, name="book"),
    path("success/", views.success_view, name="booking_success"),
    path("contactsuccess/", views.success_contact, name="contact_success"),
    # cart url
    path("cart/add/<int:id>/", views.cart_add, name="cart_add"),
    path("cart/item_clear/<int:id>/", views.item_clear, name="item_clear"),
    path("cart/item_increment/<int:id>/", views.item_increment, name="item_increment"),
    path("cart/item_decrement/<int:id>/", views.item_decrement, name="item_decrement"),
    path("cart/cart_clear/", views.cart_clear, name="cart_clear"),
    path("cart/cart-detail/", views.cart_detail, name="cart_detail"),
    path("order/", views.order, name="order"),
    path("confirmorder/", views.confirmorder, name="corder"),
    path("accounts/", include("django.contrib.auth.urls")),
    path("logout/", views.CustomLogoutView.as_view(), name="logout"),
]
