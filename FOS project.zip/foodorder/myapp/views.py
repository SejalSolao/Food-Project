from django.shortcuts import render, redirect, get_object_or_404
from .models import *
from django.contrib.auth.models import User

# from django.contrib.auth import authenticate, login, logout
from django.contrib.auth import authenticate, login as auth_login
from django.contrib import messages


from django.contrib.auth.decorators import login_required
from cart.cart import Cart  # type: ignore
from .models import Menu  # type: ignore
from datetime import datetime
from django.contrib.auth import logout
from django.views import View


def index(request):
    burgers = Menu.objects.filter(category="burger")
    snacks = Menu.objects.filter(category="snack")
    beverages = Menu.objects.filter(category="beverage")
    context = {
        "burgers": burgers,
        "snacks": snacks,
        "beverages": beverages,
    }
    return render(request, "index.html", context)


def about(request):
    return render(request, "about.html")


def contact(request):
    if request.method == "POST":
        name = request.POST.get("name")
        email = request.POST.get("email")
        subject = request.POST.get("subject")
        description = request.POST.get("description")
        print(name, email, subject, description)
        contact = Contact(
            name=name,
            email=email,
            subject=subject,
            description=description,
        )
        contact.save()

        return redirect("contact_success")
    return render(request, "contact.html")


def success_contact(request):
    return render(request, "confimrcontact.html")


def feature(request):
    return render(request, "feature.html")


def menu(request):
    burgers = Menu.objects.filter(category="burger")
    snacks = Menu.objects.filter(category="snack")
    beverages = Menu.objects.filter(category="beverage")
    context = {
        "burgers": burgers,
        "snacks": snacks,
        "beverages": beverages,
    }
    return render(request, "menu.html", context)


def account(request):
    return render(request, "account.html")


def register(request):
    if request.method == "POST":
        username = request.POST.get("username")
        email = request.POST.get("email")
        password = request.POST.get("password")

        if User.objects.filter(username=username).exists():
            messages.error(request, "username is already exists")
            return redirect("login")

        if User.objects.filter(email=email).exists():
            messages.error(request, "email is already exists")
            return redirect("login")

        user = User(
            username=username,
            email=email,
        )
        user.set_password(password)
        user.save()
        return redirect("login")


def login(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")

        print(username, password)

        user = authenticate(request, username=username, password=password)
        if user is not None:
            auth_login(request, user)
            return redirect("index")
        else:
            messages.error(request, "Email and password are Invalid")
            return redirect("login")
    return render(request, "index.html")


@login_required(login_url="/account")
def cart_add(request, id):
    cart = Cart(request)
    product = Menu.objects.get(id=id)
    cart.add(product=product)
    return redirect("cart_detail")


@login_required(login_url="/account")
def item_clear(request, id):
    cart = Cart(request)
    product = Menu.objects.get(id=id)
    cart.remove(product)
    return redirect("cart_detail")


@login_required(login_url="/account")
def item_increment(request, id):
    cart = Cart(request)
    product = Menu.objects.get(id=id)
    cart.add(product=product)
    return redirect("cart_detail")


@login_required(login_url="/account")
def item_decrement(request, id):
    cart = Cart(request)
    product = Menu.objects.get(id=id)
    cart.decrement(product=product)
    return redirect("cart_detail")


@login_required(login_url="/account")
def cart_clear(request):
    cart = Cart(request)
    cart.clear()
    return redirect("cart_detail")


@login_required(login_url="/account")
def cart_detail(request):
    cart = Cart(request)
    total_items = (
        cart.count()
    )  # Assuming count() is the method to get the total number of items in your cart
    return render(request, "cart.html", {"total_items": total_items})


def order(request):
    cart = Cart(request)
    context = {
        "cart": cart,
    }
    if request.method == "POST":
        address = request.POST.get("shipp")
        productname = request.POST.get("productname")
        totalproduct = request.POST.get("product")
        total = request.POST.get("orderprice")

        order = Order(
            address=address,
            productname=productname,
            totalproduct=totalproduct,
            total=total,
        )
        order.save()

        return redirect("corder")

    return render(request, "order.html", context)


def confirmorder(request):
    cart = Cart(request)
    context = {
        "cart": cart,
    }

    return render(request, "confirmorder.html", context)


def ordertracking(request):
    return render(request, "ordertrack.html")


def book_view(request):
    if request.method == "POST":
        name = request.POST.get("name")
        email = request.POST.get("email")
        mobile = request.POST.get("mobile")
        date = request.POST.get("date")
        time = request.POST.get("time")
        guest = request.POST.get("guest")

        month = date[0:2]
        day = date[3:5]
        year = date[6:10]

        #   YYYY-MM-DD
        newdate = f"{year}-{month}-{day}"
        print(time)
        # Save the booking to the database
        booking = Booking(
            name=name,
            email=email,
            mobile=mobile,
            date=newdate,
            booking=time,
            guest=guest,
        )
        booking.save()

        return redirect("booking_success")

    return render(request, "booking/book.html")


def success_view(request):
    return render(request, "booking/success.html")


class CustomLogoutView(View):
    def get(self, request, *args, **kwargs):
        logout(request)
        return redirect("index")  # Redirect to home page after logout

    def post(self, request, *args, **kwargs):
        logout(request)
        return redirect("index")
