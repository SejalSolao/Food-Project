from django.db import models
from django.contrib.auth.models import User
from django.contrib.auth.views import LogoutView


class Menu(models.Model):
    CATEGORY_CHOICES = [
        ("burger", "Burger"),
        ("snack", "Snack"),
        ("beverage", "Beverage"),
    ]

    Name = models.CharField(max_length=50)
    price = models.IntegerField()
    description = models.CharField(max_length=200)
    # category = models.CharField(max_length=10, choices=CATEGORY_CHOICES)
    category = models.CharField(
        max_length=10, choices=CATEGORY_CHOICES, default="burger"
    )

    def __str__(self):
        return self.Name


class Order(models.Model):
    track = [
        ("Process", "Process"),
        ("Out of delivery", "Out of delivery"),
        ("Delivered", "Delivered"),
    ]

    address = models.CharField(max_length=200)
    productname = models.TextField()
    totalproduct = models.CharField(max_length=200)
    total = models.CharField(max_length=200)
    trackorder = models.CharField(choices=track, default="Process", max_length=100)

    def __str__(self):
        return (
            self.productname
            + "---------------------------- "
            + self.total
            + "----"
            + self.trackorder
        )


class Booking(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    mobile = models.CharField(max_length=15)
    date = models.DateField()
    booking = models.CharField(max_length=50)
    guest = models.PositiveIntegerField()

    def __str__(self):
        return f"Booking for {self.name} on {self.date} at {self.booking}"


class Contact(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    subject = models.CharField(max_length=200)
    description = models.TextField()

    def __str__(self):
        return f"{self.name}"
